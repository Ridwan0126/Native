import Body from "./body";
import Header from "./header";
import Nav from "./navigation";
import Footer from "./footer"

export {Body, Nav, Header, Footer}