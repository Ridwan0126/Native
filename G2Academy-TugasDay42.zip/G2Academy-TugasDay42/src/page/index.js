import Login from "./login";
import Form from "./form";
import UserList from "./userList";
import Detail from "./detail";

export { Login, Form, UserList, Detail }