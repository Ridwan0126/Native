import InputData from './InputData'
import CardKontak from './CardKontak'

export { InputData, CardKontak }