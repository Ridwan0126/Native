import firebase from 'firebase'

firebase.initializeApp({
    apiKey: "AIzaSyCLYfzq15T6iXiGJ-XYRGDbtdloJj7h5es",
    authDomain: "crud-react-native-c9dd9.firebaseapp.com",
    databaseURL: "https://crud-react-native-c9dd9.firebaseio.com",
    projectId: "crud-react-native-c9dd9",
    storageBucket: "crud-react-native-c9dd9.appspot.com",
    messagingSenderId: "270824148310",
    appId: "1:270824148310:web:a3e8e96ed00806e8ed5af7"
})

const FIREBASE = firebase;

export default FIREBASE;