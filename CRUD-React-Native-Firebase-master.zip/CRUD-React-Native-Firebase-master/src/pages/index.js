import Home from './Home'
import TambahKontak from './TambahKontak'
import DetailKontak from './DetailKontak'
import EditKontak from './EditKontak'

export { Home, TambahKontak, DetailKontak, EditKontak }