const theme = {
  Avatar: {
    rounded: true,
  },
  Input: {
    inputContainerStyle: {
      borderBottomWidth: 0,
    },
  },
};

export default theme;
