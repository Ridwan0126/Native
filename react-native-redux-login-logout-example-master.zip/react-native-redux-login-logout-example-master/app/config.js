export const API_URL = 'https://api.league7.app/v1';
