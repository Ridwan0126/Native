## Updated version: [here](https://github.com/raduungurean/react-native-redux-auth-login-logout-example)

# react-native-redux-login-logout-example

Authentication example with react-native and redux.

|  package 	|   version	|
|---	|---	|
|  react-native 	|   0.62	|
|   react-navigation	|  3.9 (upgrade to 5 coming soon)
|   redux-thunk	|   2.3
|   react-redux	|   7 (hooks update comings soon)

## How to install
`npm install`

## How to run
`expo start`
or
`npm run android`
`npm run web`
