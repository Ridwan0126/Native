export const colors = {
  primary: '#0000E6',
  // primary: '#00ace6',
  white: '#FFFFFF',
  secondary: '#C4C4C4',
  yellow: '#FFF6D5',
  border: '#C4C4C4',
};
