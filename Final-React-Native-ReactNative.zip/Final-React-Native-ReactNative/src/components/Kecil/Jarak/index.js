import React from 'react';
import {View, Text} from 'react-native';

const Jarak = ({width, height}) => {
  return <View style={{height: height, width: width}} />;
};

export default Jarak;
