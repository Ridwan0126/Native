import PBB from './PBB.png';
import PLN from './PLN.png';
import PESAWAT from './PESAWAT.png';
import KERETA from './KERETA.png';

export {PBB, PLN, PESAWAT, KERETA};
