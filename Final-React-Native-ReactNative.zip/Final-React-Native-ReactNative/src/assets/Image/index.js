import Logo from './logo.svg';
import Slider1 from './slider1.png';
import Slider2 from './slider2.png';
import ProfileSinchan from './ProfileSinchan.jpg';
import Default from './default.jpg';
export {Logo, Slider1, Slider2, ProfileSinchan, Default};
