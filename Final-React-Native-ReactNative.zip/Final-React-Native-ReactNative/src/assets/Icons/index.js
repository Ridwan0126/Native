import Home01 from './Home01.svg';
import Home02 from './Home02.svg';
import Shop01 from './Shop01.svg';
import Shop02 from './Shop02.svg';
import Profile01 from './Profile01.svg';
import Profile02 from './Profile02.svg';
import Search from './Search.svg';
import Keranjang from './Keranjang.svg';
import Password from './Password.svg';
import Shoping from './Shoping.svg';
import LogOut from './LogOut.svg';
import PanahKanan from './PanahKanan.svg';
import Profile from './Profile.svg';
import Kembali from './Kembali.svg';
import Hapus from './Hapus.svg';
import Kanan from './Kanan.svg';
import Reg1 from './Reg01.svg';
import Reg2 from './Reg02.svg';
import Kembali2 from './Kembali2.svg';

export {
  Kembali2,
  Reg1,
  Reg2,
  Kanan,
  Hapus,
  Search,
  Keranjang,
  Home01,
  Home02,
  Shop01,
  Shop02,
  Profile01,
  Profile02,
  Password,
  Shoping,
  LogOut,
  PanahKanan,
  Profile,
  Kembali,
};
