import BaliHotel from './BaliHotel.jpg';
import BaliHotel2 from './BaliHotel2.jpg';
import BaliHotel3 from './BaliHotel3.jpg';
import LembangHotel from './LembangHotel.jpg';
import LembangHotel2 from './LembangHotel2.jpg';
import LembangHotel3 from './LembangHotel3.jpg';
import SyariahHotel from './SyariahHotel.jpg';
import SyariahHotel2 from './SyariahHotel2.png';
import JakartaHotel from './JakartaHotel.jpg';
import JogjaHotel from './JogjaHotel.jpg';

export {
  BaliHotel,
  BaliHotel2,
  BaliHotel3,
  LembangHotel,
  LembangHotel2,
  LembangHotel3,
  SyariahHotel,
  SyariahHotel2,
  JakartaHotel,
  JogjaHotel,
};
