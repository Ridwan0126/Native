import {ProfileSinchan} from '../../assets';

export const dummyProfile = {
  nama: 'Psycho',
  email: 'Psycho123@gmail.com',
  nomerHp: '085712312333',
  alamat: 'Jl. Ronggowarsito, No 102',
  kota: 'Semarang',
  provinsi: 'Jawa Tengah',
  avatar: ProfileSinchan,
};
