import React from 'react';

const FirebaseContext = new React.createContext(null);
export default FirebaseContext;
