import { Dimensions } from "react-native"

export const h = Dimensions.get('window').height/100;
export const w = Dimensions.get('window').width/100;