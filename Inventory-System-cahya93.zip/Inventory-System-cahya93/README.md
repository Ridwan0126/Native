# Inventory-System

Tugas Bootcamp G2 Academy

<h3>Backend on</h3>
https://github.com/cahya93/backend-tokopedei
