package com.travel.carRentals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarRentalsApplicationTests {

	@Test
	void contextLoads() {
	}

}
