# car_rentals
car rentals for final projects in g2 academy
