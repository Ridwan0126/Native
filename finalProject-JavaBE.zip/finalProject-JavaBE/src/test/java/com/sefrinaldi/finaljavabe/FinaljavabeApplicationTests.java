package com.sefrinaldi.finaljavabe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinaljavabeApplicationTests {

	@Test
	void contextLoads() {
	}

}
