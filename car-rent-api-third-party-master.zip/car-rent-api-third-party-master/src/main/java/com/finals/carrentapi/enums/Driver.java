package com.finals.carrentapi.enums;

public enum Driver {
    USEDRIVER, WITHOUTDRIVER
}
