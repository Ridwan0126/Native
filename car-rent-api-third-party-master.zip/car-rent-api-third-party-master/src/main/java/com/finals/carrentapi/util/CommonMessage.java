package com.finals.carrentapi.util;

public interface CommonMessage {
    public static final String SQL = "SqlMapConfig.xml";
    public static final String AVAILABLE = "AVAILABLE";
    public static final String INSERT_CAR = "Car.insertCar";
    public static final String GET_AVA_CAR = "Car.getAvailableCars";
    public static final String GET_AVA_CAR_BY_CITY = "Car.getAvailableCarsByCity";

}
