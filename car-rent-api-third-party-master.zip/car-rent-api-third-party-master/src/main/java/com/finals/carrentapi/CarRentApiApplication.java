package com.finals.carrentapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarRentApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(CarRentApiApplication.class, args);
    }

}
