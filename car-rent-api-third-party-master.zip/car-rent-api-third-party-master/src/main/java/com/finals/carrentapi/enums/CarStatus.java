package com.finals.carrentapi.enums;

public enum CarStatus {
    AVAILABLE, UNAVAILABLE, ON_RENT, BOOKED
}
