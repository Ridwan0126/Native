import React from "react";
import "./footer.css";

function Footer() {
  return (
    <div className="footer-container">
      <small class="website-rights">
        Bootcamp G2 Academy | Class Bootcamp Mei 2021
      </small>
    </div>
  );
}

export default Footer;
