import Header from "./header";
import Nav from "./navigation";
import Body from "./body";
import Footer from "./footer";

export { Header, Nav, Body, Footer };
