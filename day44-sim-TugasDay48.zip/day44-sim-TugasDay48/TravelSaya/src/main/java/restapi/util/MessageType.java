package main.java.restapi.util;

public class MessageType {
    private String message;

    public MessageType(String message){
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

}
