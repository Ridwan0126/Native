import Home from "./home";
import Login from "./login";
import Splash from "./splash";


export { Home, Login, Splash }