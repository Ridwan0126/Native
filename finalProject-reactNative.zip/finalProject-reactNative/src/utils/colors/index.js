export const colors = {
    primary: '#7579E7',
    secondary: '#9AB3F5',
    regular: '#A3D8F4',
    light: '#B9FFFC',
    white: '#FFF',
    black: '#000',
    border: '#C4C4C4'
}